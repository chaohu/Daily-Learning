#ifndef SUPPORT_H
#define SUPPORT_H

/* function prototypes */
void initialize_bomb(void);


#endif /* SUPPORT_H */


