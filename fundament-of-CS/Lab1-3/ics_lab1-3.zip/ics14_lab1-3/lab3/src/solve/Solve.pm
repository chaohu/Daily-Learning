#
# Configuration file for the buflab autosolvers
#
package Solve;

# Where are the buffer bomb binaries?
$BINDIR = "..";

# What executable file should be used in generating a solution string?
$EXECUTABLE = "$BINDIR/bufbomb";

# Every module must end with true
1;


