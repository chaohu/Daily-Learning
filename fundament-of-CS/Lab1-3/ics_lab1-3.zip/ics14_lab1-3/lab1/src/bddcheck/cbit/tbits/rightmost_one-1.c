.model DD
.inputs
.outputs F_0
.names 89e22f
1
.names 89e22f F_0
1 1
.end
