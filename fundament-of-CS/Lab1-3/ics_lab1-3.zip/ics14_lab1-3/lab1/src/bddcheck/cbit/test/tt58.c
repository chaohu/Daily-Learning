int test_trueFiveEighths(int x)
{
    long long int x5 = (long long int) x * 5;
    return (int) (x5/8);
}
