int test_ezThreeFourths(int x)
{
    return (x*3)/4;
}
