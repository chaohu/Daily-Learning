#include "bitAnd.c"
#include "getByte.c"
#include "logicalShift.c"
#include "bitCount.c"
#include "bang.c"
#include "tmin.c"
#include "fitsBits.c"
#include "divpwr2.c"
#include "negate.c"
#include "isPositive.c"
#include "isLessOrEqual.c"
#include "ilog2.c"
#include "float_neg.c"
#include "float_i2f.c"
#include "float_twice.c"



